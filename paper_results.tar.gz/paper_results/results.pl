:- [
  '$HOME/prelude',
  cnf_to_drat_times, 
  drat_sizes, 
  drat_to_lrat_times, 
  drat_to_lrat_mems, 
  lrat_from_drat_sizes, 
  lrat_from_drat_check_times, 
  cnf_to_frat_times,
  frat_sizes, 
  frat_to_lrat_times, 
  frat_to_lrat_mems, 
  temp_sizes,
  lrat_from_frat_sizes,
  lrat_from_frat_check_times
].